import { useState } from 'react';
import { Rule, Link as LinkType, RuleType, RuleConditions, RuleActions } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash2, Clock, Monitor, MapPin, TrendingUp } from 'lucide-react';

interface RuleBuilderProps {
  rules: Rule[];
  links: LinkType[];
  onAddRule: (data: Omit<Rule, 'id' | 'hub_id' | 'created_at' | 'updated_at'>) => Promise<void>;
  onUpdateRule: (rule: Rule) => Promise<void>;
  onDeleteRule: (ruleId: string) => Promise<void>;
  isLoading: boolean;
}

const RULE_ICONS = { time: Clock, device: Monitor, location: MapPin, performance: TrendingUp };

export function RuleBuilder({ rules, links, onAddRule, onUpdateRule, onDeleteRule, isLoading }: RuleBuilderProps) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [ruleType, setRuleType] = useState<RuleType>('time');
  const [action, setAction] = useState<'show' | 'hide' | 'promote'>('show');
  const [selectedLinks, setSelectedLinks] = useState<string[]>([]);

  const handleAdd = async () => {
    if (!name) return;
    await onAddRule({
      name,
      rule_type: ruleType,
      conditions: {},
      actions: { action, link_ids: selectedLinks },
      priority: rules.length,
      is_active: true,
    });
    setName('');
    setShowForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Rules ({rules.length})</h3>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2" size="sm">
          <Plus className="h-4 w-4" /> Add Rule
        </Button>
      </div>

      {showForm && (
        <Card className="border-primary/50 bg-card">
          <CardContent className="pt-4 space-y-3">
            <Input placeholder="Rule Name" value={name} onChange={(e) => setName(e.target.value)} className="bg-input" />
            <Select value={ruleType} onValueChange={(v) => setRuleType(v as RuleType)}>
              <SelectTrigger className="bg-input"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="time">Time-based</SelectItem>
                <SelectItem value="device">Device-based</SelectItem>
                <SelectItem value="location">Location-based</SelectItem>
                <SelectItem value="performance">Performance-based</SelectItem>
              </SelectContent>
            </Select>
            <Select value={action} onValueChange={(v) => setAction(v as 'show' | 'hide' | 'promote')}>
              <SelectTrigger className="bg-input"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="show">Show Links</SelectItem>
                <SelectItem value="hide">Hide Links</SelectItem>
                <SelectItem value="promote">Promote Links</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button onClick={handleAdd} disabled={isLoading} className="neon-glow">Save Rule</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {rules.map((rule) => {
          const Icon = RULE_ICONS[rule.rule_type];
          return (
            <Card key={rule.id} className="border-border bg-card">
              <CardContent className="flex items-center gap-4 py-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{rule.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">{rule.rule_type} • {rule.actions.action}</p>
                </div>
                <span className="text-xs text-muted-foreground">Priority: {rule.priority}</span>
                <Switch checked={rule.is_active} onCheckedChange={(checked) => onUpdateRule({ ...rule, is_active: checked })} />
                <Button variant="ghost" size="icon" onClick={() => onDeleteRule(rule.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
        {rules.length === 0 && <p className="text-center text-muted-foreground py-8">No rules yet. Rules let you dynamically control which links appear.</p>}
      </div>
    </div>
  );
}
