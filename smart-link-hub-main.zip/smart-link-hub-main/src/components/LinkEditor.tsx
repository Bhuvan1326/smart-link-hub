import { useState } from 'react';
import { Link as LinkType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash2, GripVertical, ExternalLink } from 'lucide-react';

interface LinkEditorProps {
  links: LinkType[];
  onAddLink: (data: { title: string; url: string; description?: string }) => Promise<void>;
  onUpdateLink: (link: LinkType) => Promise<void>;
  onDeleteLink: (linkId: string) => Promise<void>;
  isLoading: boolean;
}

export function LinkEditor({ links, onAddLink, onUpdateLink, onDeleteLink, isLoading }: LinkEditorProps) {
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleAdd = async () => {
    if (!newTitle || !newUrl) return;
    await onAddLink({ title: newTitle, url: newUrl });
    setNewTitle('');
    setNewUrl('');
    setShowForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Links ({links.length})</h3>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2" size="sm">
          <Plus className="h-4 w-4" /> Add Link
        </Button>
      </div>

      {showForm && (
        <Card className="border-primary/50 bg-card">
          <CardContent className="pt-4 space-y-3">
            <Input placeholder="Link Title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="bg-input" />
            <Input placeholder="https://..." value={newUrl} onChange={(e) => setNewUrl(e.target.value)} className="bg-input" />
            <div className="flex gap-2">
              <Button onClick={handleAdd} disabled={isLoading} className="neon-glow">Save</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {links.map((link) => (
          <Card key={link.id} className="border-border bg-card">
            <CardContent className="flex items-center gap-4 py-3">
              <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{link.title}</p>
                <p className="text-xs text-muted-foreground truncate">{link.url}</p>
              </div>
              <span className="text-xs text-primary">{link.click_count} clicks</span>
              <Switch checked={link.is_active} onCheckedChange={(checked) => onUpdateLink({ ...link, is_active: checked })} />
              <a href={link.url} target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="icon"><ExternalLink className="h-4 w-4" /></Button>
              </a>
              <Button variant="ghost" size="icon" onClick={() => onDeleteLink(link.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </CardContent>
          </Card>
        ))}
        {links.length === 0 && <p className="text-center text-muted-foreground py-8">No links yet. Add your first link above.</p>}
      </div>
    </div>
  );
}
