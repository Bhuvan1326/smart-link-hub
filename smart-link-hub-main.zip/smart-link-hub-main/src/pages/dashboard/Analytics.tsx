import { useParams, Link } from 'react-router-dom';
import { useHub } from '@/hooks/useHubs';
import { useLinks } from '@/hooks/useLinks';
import { useAnalyticsSummary, useHubVisits, useLinkClicks } from '@/hooks/useAnalytics';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DashboardLayout } from '@/components/DashboardLayout';
import { ArrowLeft, Eye, MousePointer, TrendingUp, TrendingDown, Loader2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function AnalyticsPage() {
  const { id } = useParams<{ id: string }>();
  const { data: hub, isLoading: hubLoading } = useHub(id!);
  const { data: links } = useLinks(id!);
  const { data: visits } = useHubVisits(id!);
  const { data: clicks } = useLinkClicks(id!);
  const analytics = useAnalyticsSummary(id!);

  if (hubLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!hub) {
    return (
      <DashboardLayout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-4">Hub not found</h2>
          <Link to="/dashboard">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </DashboardLayout>
    );
  }

  // Prepare link click data for chart
  const linkClickData = links?.map(link => ({
    name: link.title.slice(0, 15) + (link.title.length > 15 ? '...' : ''),
    clicks: analytics.clicksByLink[link.id] || 0,
  })) || [];

  // Device breakdown for pie chart
  const deviceData = Object.entries(analytics.deviceBreakdown).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value,
  }));

  const COLORS = ['#39FF14', '#00FF88', '#88FF00', '#CCFF00'];

  // Top and least performing links
  const sortedLinks = [...(links || [])].sort((a, b) => 
    (analytics.clicksByLink[b.id] || 0) - (analytics.clicksByLink[a.id] || 0)
  );
  const topLinks = sortedLinks.slice(0, 3);
  const leastLinks = sortedLinks.slice(-3).reverse();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link to={`/dashboard/hubs/${hub.id}`}>
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Analytics</h1>
            <p className="text-muted-foreground text-sm">{hub.title}</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Eye className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{analytics.totalVisits}</p>
                  <p className="text-sm text-muted-foreground">Total Visits</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <MousePointer className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{analytics.totalClicks}</p>
                  <p className="text-sm text-muted-foreground">Total Clicks</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">
                    {analytics.totalVisits > 0 
                      ? ((analytics.totalClicks / analytics.totalVisits) * 100).toFixed(1)
                      : 0}%
                  </p>
                  <p className="text-sm text-muted-foreground">Click Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <TrendingDown className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{links?.length || 0}</p>
                  <p className="text-sm text-muted-foreground">Total Links</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Visits Over Time */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Visits (Last 7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.visitsOverTime}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis 
                      dataKey="date" 
                      stroke="#666"
                      tickFormatter={(value) => new Date(value).toLocaleDateString('en', { weekday: 'short' })}
                    />
                    <YAxis stroke="#666" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#111', 
                        border: '1px solid #333',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="count" fill="#39FF14" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Device Breakdown */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Device Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {deviceData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={deviceData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {deviceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#111', 
                          border: '1px solid #333',
                          borderRadius: '8px',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-full items-center justify-center text-muted-foreground">
                    No device data yet
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Link Clicks Chart */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Clicks by Link</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              {linkClickData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={linkClickData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis type="number" stroke="#666" />
                    <YAxis type="category" dataKey="name" stroke="#666" width={100} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#111', 
                        border: '1px solid #333',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="clicks" fill="#39FF14" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center text-muted-foreground">
                  No links yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Top & Least Performing */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Top Performing Links
              </CardTitle>
            </CardHeader>
            <CardContent>
              {topLinks.length > 0 ? (
                <div className="space-y-3">
                  {topLinks.map((link, index) => (
                    <div key={link.id} className="flex items-center justify-between rounded-lg bg-secondary p-3">
                      <div className="flex items-center gap-3">
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
                          {index + 1}
                        </span>
                        <span className="font-medium">{link.title}</span>
                      </div>
                      <span className="text-primary font-bold">{analytics.clicksByLink[link.id] || 0} clicks</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-4">No links yet</p>
              )}
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5 text-destructive" />
                Least Performing Links
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leastLinks.length > 0 ? (
                <div className="space-y-3">
                  {leastLinks.map((link, index) => (
                    <div key={link.id} className="flex items-center justify-between rounded-lg bg-secondary p-3">
                      <div className="flex items-center gap-3">
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-destructive/20 text-xs font-bold text-destructive">
                          {leastLinks.length - index}
                        </span>
                        <span className="font-medium">{link.title}</span>
                      </div>
                      <span className="text-muted-foreground">{analytics.clicksByLink[link.id] || 0} clicks</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-4">No links yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
