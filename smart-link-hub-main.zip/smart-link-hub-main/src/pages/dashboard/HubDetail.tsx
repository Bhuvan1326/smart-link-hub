import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useHub, useUpdateHub, useDeleteHub } from '@/hooks/useHubs';
import { useLinks, useCreateLink, useUpdateLink, useDeleteLink } from '@/hooks/useLinks';
import { useRules, useCreateRule, useUpdateRule, useDeleteRule } from '@/hooks/useRules';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { DashboardLayout } from '@/components/DashboardLayout';
import { LinkEditor } from '@/components/LinkEditor';
import { RuleBuilder } from '@/components/RuleBuilder';
import { Loader2, ExternalLink, Trash2, Save, ArrowLeft, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { Link as LinkType, Rule as RuleType } from '@/lib/types';

export default function HubDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: hub, isLoading: hubLoading } = useHub(id!);
  const { data: links, isLoading: linksLoading } = useLinks(id!);
  const { data: rules, isLoading: rulesLoading } = useRules(id!);
  
  const updateHub = useUpdateHub();
  const deleteHub = useDeleteHub();
  const createLink = useCreateLink();
  const updateLink = useUpdateLink();
  const deleteLink = useDeleteLink();
  const createRule = useCreateRule();
  const updateRule = useUpdateRule();
  const deleteRule = useDeleteRule();

  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [hasChanges, setHasChanges] = useState(false);

  // Initialize form when hub loads
  useState(() => {
    if (hub) {
      setEditTitle(hub.title);
      setEditDescription(hub.description || '');
      setIsActive(hub.is_active);
    }
  });

  if (hubLoading || linksLoading || rulesLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!hub) {
    return (
      <DashboardLayout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-4">Hub not found</h2>
          <Link to="/dashboard">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </DashboardLayout>
    );
  }

  const handleSaveHub = async () => {
    await updateHub.mutateAsync({
      id: hub.id,
      title: editTitle || hub.title,
      description: editDescription,
      is_active: isActive,
    });
    setHasChanges(false);
  };

  const handleDeleteHub = async () => {
    if (confirm('Are you sure you want to delete this hub? This action cannot be undone.')) {
      await deleteHub.mutateAsync(hub.id);
      navigate('/dashboard');
    }
  };

  const handleAddLink = async (data: { title: string; url: string; description?: string }) => {
    await createLink.mutateAsync({
      hub_id: hub.id,
      title: data.title,
      url: data.url,
      description: data.description,
      position: (links?.length || 0),
    });
  };

  const handleUpdateLink = async (link: LinkType) => {
    await updateLink.mutateAsync({
      id: link.id,
      hub_id: hub.id,
      title: link.title,
      url: link.url,
      description: link.description,
      is_active: link.is_active,
    });
  };

  const handleDeleteLink = async (linkId: string) => {
    await deleteLink.mutateAsync({ id: linkId, hub_id: hub.id });
  };

  const handleAddRule = async (data: Omit<RuleType, 'id' | 'hub_id' | 'created_at' | 'updated_at'>) => {
    await createRule.mutateAsync({
      hub_id: hub.id,
      name: data.name,
      rule_type: data.rule_type,
      conditions: data.conditions,
      actions: data.actions,
      priority: data.priority,
    });
  };

  const handleUpdateRule = async (rule: RuleType) => {
    await updateRule.mutateAsync({
      id: rule.id,
      hub_id: hub.id,
      name: rule.name,
      rule_type: rule.rule_type,
      conditions: rule.conditions,
      actions: rule.actions,
      priority: rule.priority,
      is_active: rule.is_active,
    });
  };

  const handleDeleteRule = async (ruleId: string) => {
    await deleteRule.mutateAsync({ id: ruleId, hub_id: hub.id });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">{hub.title}</h1>
              <p className="text-muted-foreground text-sm">/u/{hub.slug}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link to={`/dashboard/hubs/${hub.id}/analytics`}>
              <Button variant="outline" className="gap-2">
                <BarChart3 className="h-4 w-4" /> Analytics
              </Button>
            </Link>
              <a
               href={`${import.meta.env.VITE_PUBLIC_APP_URL}/u/${hub.slug}`}
                target="_blank"
                rel="noopener noreferrer"
                >
              <Button variant="outline" className="gap-2">
                <ExternalLink className="h-4 w-4" /> Preview
              </Button>
            </a>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="links" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="links">Links</TabsTrigger>
            <TabsTrigger value="rules">Rules</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="links" className="space-y-6">
            <LinkEditor
              links={links || []}
              onAddLink={handleAddLink}
              onUpdateLink={handleUpdateLink}
              onDeleteLink={handleDeleteLink}
              isLoading={createLink.isPending || updateLink.isPending || deleteLink.isPending}
            />
          </TabsContent>

          <TabsContent value="rules" className="space-y-6">
            <RuleBuilder
              rules={rules || []}
              links={links || []}
              onAddRule={handleAddRule}
              onUpdateRule={handleUpdateRule}
              onDeleteRule={handleDeleteRule}
              isLoading={createRule.isPending || updateRule.isPending || deleteRule.isPending}
            />
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Hub Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={editTitle || hub.title}
                    onChange={(e) => {
                      setEditTitle(e.target.value);
                      setHasChanges(true);
                    }}
                    className="bg-input"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={editDescription || hub.description || ''}
                    onChange={(e) => {
                      setEditDescription(e.target.value);
                      setHasChanges(true);
                    }}
                    className="min-h-[100px] bg-input"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Hub Status</Label>
                    <p className="text-sm text-muted-foreground">
                      When disabled, your hub won't be accessible publicly
                    </p>
                  </div>
                  <Switch
                    checked={isActive !== undefined ? isActive : hub.is_active}
                    onCheckedChange={(checked) => {
                      setIsActive(checked);
                      setHasChanges(true);
                    }}
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <Button
                    onClick={handleSaveHub}
                    className="neon-glow gap-2"
                    disabled={!hasChanges || updateHub.isPending}
                  >
                    {updateHub.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Save className="h-4 w-4" /> Save Changes
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-destructive/50 bg-card">
              <CardHeader>
                <CardTitle className="text-destructive">Danger Zone</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground">
                  Once you delete a hub, there is no going back. Please be certain.
                </p>
                <Button
                  variant="destructive"
                  onClick={handleDeleteHub}
                  disabled={deleteHub.isPending}
                  className="gap-2"
                >
                  {deleteHub.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4" /> Delete Hub
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
