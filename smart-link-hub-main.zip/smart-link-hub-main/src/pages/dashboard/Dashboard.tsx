import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { useHubs } from '@/hooks/useHubs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Plus, Link2, ExternalLink, BarChart3, Settings, Loader2 } from 'lucide-react';

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: hubs, isLoading } = useHubs();

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Your Hubs</h1>
            <p className="text-muted-foreground">
              Manage your link hubs and track performance
            </p>
          </div>
          <Link to="/dashboard/hubs/new">
            <Button className="neon-glow gap-2">
              <Plus className="h-4 w-4" /> Create Hub
            </Button>
          </Link>
        </div>

        {/* Hubs Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : hubs && hubs.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {hubs.map((hub) => (
              <Card key={hub.id} className="border-border bg-card transition-all hover:border-primary/50">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Link2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{hub.title}</CardTitle>
                        <CardDescription className="text-xs">
                          /u/{hub.slug}
                        </CardDescription>
                      </div>
                    </div>
                    <span className={`rounded-full px-2 py-0.5 text-xs ${
                      hub.is_active 
                        ? 'bg-primary/20 text-primary' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {hub.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 line-clamp-2 text-sm text-muted-foreground">
                    {hub.description || 'No description'}
                  </p>
                  <div className="flex gap-2">
                    <Link to={`/dashboard/hubs/${hub.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full gap-1">
                        <Settings className="h-3 w-3" /> Manage
                      </Button>
                    </Link>
                    <Link to={`/dashboard/hubs/${hub.id}/analytics`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full gap-1">
                        <BarChart3 className="h-3 w-3" /> Analytics
                      </Button>
                    </Link>
                    <a href={`/u/${hub.slug}`} target="_blank" rel="noopener noreferrer">
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-border bg-card/50">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Link2 className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">No hubs yet</h3>
              <p className="mb-6 text-center text-muted-foreground">
                Create your first link hub to get started
              </p>
              <Link to="/dashboard/hubs/new">
                <Button className="neon-glow gap-2">
                  <Plus className="h-4 w-4" /> Create Your First Hub
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
