import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useHubBySlug } from '@/hooks/useHubs';
import { useLinks } from '@/hooks/useLinks';
import { useRules } from '@/hooks/useRules';
import { useTrackVisit, useTrackClick } from '@/hooks/useAnalytics';
import { evaluateRules, detectDeviceType } from '@/lib/rule-engine';
import { Loader2, ExternalLink } from 'lucide-react';

export default function PublicHubPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: hub, isLoading: hubLoading, error } = useHubBySlug(slug!);
  const { data: links } = useLinks(hub?.id || '');
  const { data: rules } = useRules(hub?.id || '');
  const trackVisit = useTrackVisit();
  const trackClick = useTrackClick();

  useEffect(() => {
    if (hub?.id) {
      trackVisit.mutate(hub.id);
    }
  }, [hub?.id]);

  const handleLinkClick = (linkId: string) => {
    if (hub?.id) {
      trackClick.mutate({ linkId, hubId: hub.id });
    }
  };

  if (hubLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Loader2 className="h-8 w-8 animate-spin text-[#39FF14]" />
      </div>
    );
  }

  if (error || !hub) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-black text-white">
        <h1 className="text-2xl font-bold mb-2">Hub Not Found</h1>
        <p className="text-gray-400">This link hub doesn't exist or is inactive.</p>
      </div>
    );
  }

  const visitorContext = {
    deviceType: detectDeviceType(navigator.userAgent),
    userAgent: navigator.userAgent,
    currentTime: new Date(),
  };

  const processedLinks = links && rules 
    ? evaluateRules(links, rules, visitorContext)
    : links || [];

  return (
    <div className="min-h-screen bg-black px-4 py-12" style={{ backgroundColor: hub.theme.background }}>
      <div className="mx-auto max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-white mb-2">{hub.title}</h1>
          {hub.description && <p className="text-gray-400">{hub.description}</p>}
        </div>

        <div className="space-y-3">
          {processedLinks.map((link) => (
            <a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => handleLinkClick(link.id)}
              className="flex items-center justify-between rounded-xl border-2 p-4 transition-all hover:scale-[1.02]"
              style={{
                borderColor: hub.theme.accent,
                backgroundColor: 'rgba(57, 255, 20, 0.1)',
              }}
            >
              <span className="font-medium text-white">{link.title}</span>
              <ExternalLink className="h-4 w-4" style={{ color: hub.theme.accent }} />
            </a>
          ))}
        </div>

        <p className="mt-12 text-center text-xs text-gray-500">
          Powered by LinkHub
        </p>
      </div>
    </div>
  );
}
