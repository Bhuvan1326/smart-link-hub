import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Link2, BarChart3, Zap, Shield } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Link2 className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold neon-text">LinkHub</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link to="/auth/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link to="/auth/signup">
              <Button className="neon-glow">Get Started</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <h1 className="mb-6 text-5xl font-bold leading-tight md:text-7xl">
          One Link to
          <span className="block text-primary neon-text">Rule Them All</span>
        </h1>
        <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground md:text-xl">
          Create smart, dynamic link hubs that adapt to your audience. 
          Time-based rules, device detection, and powerful analytics.
        </p>
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
          <Link to="/auth/signup">
            <Button size="lg" className="neon-glow gap-2">
              Create Your Hub <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
          <Link to="/auth/login">
            <Button size="lg" variant="outline" className="border-primary/50 hover:bg-primary/10">
              Sign In
            </Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <h2 className="mb-12 text-center text-3xl font-bold md:text-4xl">
          Smart Features for <span className="text-primary">Smart Creators</span>
        </h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <FeatureCard
            icon={<Link2 className="h-8 w-8" />}
            title="Dynamic Links"
            description="Create multiple links under one shareable URL. Organize and prioritize with ease."
          />
          <FeatureCard
            icon={<Zap className="h-8 w-8" />}
            title="Smart Rules"
            description="Show different links based on time, device, location, or performance."
          />
          <FeatureCard
            icon={<BarChart3 className="h-8 w-8" />}
            title="Rich Analytics"
            description="Track visits, clicks, and performance. Know what works best."
          />
          <FeatureCard
            icon={<Shield className="h-8 w-8" />}
            title="Secure & Fast"
            description="Enterprise-grade security with lightning-fast load times."
          />
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t border-border py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-4 text-3xl font-bold md:text-4xl">
            Ready to <span className="text-primary neon-text">Level Up</span>?
          </h2>
          <p className="mx-auto mb-8 max-w-xl text-muted-foreground">
            Join thousands of creators, educators, and businesses using Smart Link Hub.
          </p>
          <Link to="/auth/signup">
            <Button size="lg" className="neon-glow">
              Start for Free
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 LinkHub. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10">
      <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3 text-primary">
        {icon}
      </div>
      <h3 className="mb-2 text-xl font-semibold">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}

export default Index;
