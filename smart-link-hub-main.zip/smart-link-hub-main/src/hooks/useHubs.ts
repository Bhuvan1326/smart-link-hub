import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Hub, HubTheme } from '@/lib/types';
import { useAuth } from '@/lib/auth';
import { toast } from 'sonner';
import { Json } from '@/integrations/supabase/types';

function parseHubTheme(theme: Json | null): HubTheme {
  if (theme && typeof theme === 'object' && !Array.isArray(theme)) {
    return {
      background: (theme as Record<string, unknown>).background as string ?? '#000000',
      accent: (theme as Record<string, unknown>).accent as string ?? '#39FF14',
    };
  }
  return { background: '#000000', accent: '#39FF14' };
}

export function useHubs() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['hubs', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('hubs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      return data.map(hub => ({
        ...hub,
        theme: parseHubTheme(hub.theme)
      })) as Hub[];
    },
    enabled: !!user,
  });
}

export function useHub(hubId: string) {
  return useQuery({
    queryKey: ['hub', hubId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hubs')
        .select('*')
        .eq('id', hubId)
        .single();

      if (error) throw error;
      
      return {
        ...data,
        theme: parseHubTheme(data.theme)
      } as Hub;
    },
    enabled: !!hubId,
  });
}

export function useHubBySlug(slug: string) {
  return useQuery({
    queryKey: ['hub', 'slug', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hubs')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      
      return {
        ...data,
        theme: parseHubTheme(data.theme)
      } as Hub;
    },
    enabled: !!slug,
  });
}

export function useCreateHub() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: { title: string; description?: string; slug: string }) => {
      if (!user) throw new Error('Not authenticated');

      const { data: hub, error } = await supabase
        .from('hubs')
        .insert({
          user_id: user.id,
          title: data.title,
          description: data.description || null,
          slug: data.slug,
        })
        .select()
        .single();

      if (error) throw error;
      return hub;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hubs'] });
      toast.success('Hub created successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useUpdateHub() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, theme, ...rest }: Partial<Hub> & { id: string }) => {
      const updateData: Record<string, unknown> = { ...rest };
      if (theme) {
        updateData.theme = theme as unknown as Json;
      }

      const { data: hub, error } = await supabase
        .from('hubs')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return hub;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['hubs'] });
      queryClient.invalidateQueries({ queryKey: ['hub', data.id] });
      toast.success('Hub updated successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useDeleteHub() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (hubId: string) => {
      const { error } = await supabase
        .from('hubs')
        .delete()
        .eq('id', hubId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hubs'] });
      toast.success('Hub deleted successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}
