import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Link } from '@/lib/types';
import { toast } from 'sonner';

export function useLinks(hubId: string) {
  return useQuery({
    queryKey: ['links', hubId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('links')
        .select('*')
        .eq('hub_id', hubId)
        .order('position', { ascending: true });

      if (error) throw error;
      return data as Link[];
    },
    enabled: !!hubId,
  });
}

export function useCreateLink() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      hub_id: string;
      title: string;
      url: string;
      description?: string;
      icon?: string;
      position?: number;
    }) => {
      const { data: link, error } = await supabase
        .from('links')
        .insert({
          hub_id: data.hub_id,
          title: data.title,
          url: data.url,
          description: data.description || null,
          icon: data.icon || null,
          position: data.position ?? 0,
        })
        .select()
        .single();

      if (error) throw error;
      return link;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['links', data.hub_id] });
      toast.success('Link created successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useUpdateLink() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, hub_id, ...data }: Partial<Link> & { id: string; hub_id: string }) => {
      const { data: link, error } = await supabase
        .from('links')
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { ...link, hub_id };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['links', data.hub_id] });
      toast.success('Link updated successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useDeleteLink() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, hub_id }: { id: string; hub_id: string }) => {
      const { error } = await supabase
        .from('links')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { hub_id };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['links', data.hub_id] });
      toast.success('Link deleted successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useReorderLinks() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ hubId, links }: { hubId: string; links: { id: string; position: number }[] }) => {
      const promises = links.map(link =>
        supabase
          .from('links')
          .update({ position: link.position })
          .eq('id', link.id)
      );

      await Promise.all(promises);
      return hubId;
    },
    onSuccess: (hubId) => {
      queryClient.invalidateQueries({ queryKey: ['links', hubId] });
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}
