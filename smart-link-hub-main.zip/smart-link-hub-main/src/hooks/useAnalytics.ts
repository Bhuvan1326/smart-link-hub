import { useQuery, useMutation } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { HubVisit, LinkClick } from '@/lib/types';
import { detectDeviceType } from '@/lib/rule-engine';

export function useHubVisits(hubId: string) {
  return useQuery({
    queryKey: ['hub-visits', hubId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hub_visits')
        .select('*')
        .eq('hub_id', hubId)
        .order('visited_at', { ascending: false });

      if (error) throw error;
      return data as HubVisit[];
    },
    enabled: !!hubId,
  });
}

export function useLinkClicks(hubId: string) {
  return useQuery({
    queryKey: ['link-clicks', hubId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('link_clicks')
        .select('*')
        .eq('hub_id', hubId)
        .order('clicked_at', { ascending: false });

      if (error) throw error;
      return data as LinkClick[];
    },
    enabled: !!hubId,
  });
}

export function useTrackVisit() {
  return useMutation({
    mutationFn: async (hubId: string) => {
      const userAgent = navigator.userAgent;
      const deviceType = detectDeviceType(userAgent);
      const referrer = document.referrer || null;

      const { error } = await supabase.from('hub_visits').insert({
        hub_id: hubId,
        user_agent: userAgent,
        device_type: deviceType,
        referrer: referrer,
      });

      if (error) throw error;
    },
  });
}

export function useTrackClick() {
  return useMutation({
    mutationFn: async ({ linkId, hubId }: { linkId: string; hubId: string }) => {
      const userAgent = navigator.userAgent;
      const deviceType = detectDeviceType(userAgent);

      // Insert click record
      const { error: clickError } = await supabase.from('link_clicks').insert({
        link_id: linkId,
        hub_id: hubId,
        user_agent: userAgent,
        device_type: deviceType,
      });

      if (clickError) throw clickError;

      // Increment click count using RPC
      const { error: rpcError } = await supabase.rpc('increment_link_click', {
        link_id_param: linkId,
      });

      if (rpcError) throw rpcError;
    },
  });
}

export function useAnalyticsSummary(hubId: string) {
  const { data: visits } = useHubVisits(hubId);
  const { data: clicks } = useLinkClicks(hubId);

  const totalVisits = visits?.length ?? 0;
  const totalClicks = clicks?.length ?? 0;

  // Click counts by link
  const clicksByLink = clicks?.reduce((acc, click) => {
    acc[click.link_id] = (acc[click.link_id] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) ?? {};

  // Device breakdown
  const deviceBreakdown = visits?.reduce((acc, visit) => {
    const device = visit.device_type || 'unknown';
    acc[device] = (acc[device] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) ?? {};

  // Visits over time (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split('T')[0];
  });

  const visitsOverTime = last7Days.map(date => {
    const count = visits?.filter(v => 
      v.visited_at.startsWith(date)
    ).length ?? 0;
    return { date, count };
  });

  return {
    totalVisits,
    totalClicks,
    clicksByLink,
    deviceBreakdown,
    visitsOverTime,
  };
}
