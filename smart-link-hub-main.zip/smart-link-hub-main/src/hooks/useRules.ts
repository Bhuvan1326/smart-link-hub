import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Rule, RuleConditions, RuleActions, RuleType } from '@/lib/types';
import { toast } from 'sonner';
import { Json } from '@/integrations/supabase/types';

function parseRuleConditions(conditions: Json | null): RuleConditions {
  if (conditions && typeof conditions === 'object' && !Array.isArray(conditions)) {
    return conditions as unknown as RuleConditions;
  }
  return {};
}

function parseRuleActions(actions: Json | null): RuleActions {
  if (actions && typeof actions === 'object' && !Array.isArray(actions)) {
    const obj = actions as Record<string, unknown>;
    return {
      action: (obj.action as 'show' | 'hide' | 'promote' | 'demote') ?? 'show',
      link_ids: (obj.link_ids as string[]) ?? [],
      position: obj.position as number | undefined,
    };
  }
  return { action: 'show', link_ids: [] };
}

export function useRules(hubId: string) {
  return useQuery({
    queryKey: ['rules', hubId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('rules')
        .select('*')
        .eq('hub_id', hubId)
        .order('priority', { ascending: false });

      if (error) throw error;
      
      return data.map(rule => ({
        ...rule,
        rule_type: rule.rule_type as RuleType,
        conditions: parseRuleConditions(rule.conditions),
        actions: parseRuleActions(rule.actions)
      })) as Rule[];
    },
    enabled: !!hubId,
  });
}

export function useCreateRule() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      hub_id: string;
      name: string;
      rule_type: RuleType;
      conditions: RuleConditions;
      actions: RuleActions;
      priority?: number;
    }) => {
      const { data: rule, error } = await supabase
        .from('rules')
        .insert({
          hub_id: data.hub_id,
          name: data.name,
          rule_type: data.rule_type,
          conditions: data.conditions as unknown as Json,
          actions: data.actions as unknown as Json,
          priority: data.priority ?? 0,
        })
        .select()
        .single();

      if (error) throw error;
      return rule;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['rules', data.hub_id] });
      toast.success('Rule created successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useUpdateRule() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, hub_id, conditions, actions, ...rest }: Partial<Rule> & { id: string; hub_id: string }) => {
      const updateData: Record<string, unknown> = { ...rest };
      if (conditions) {
        updateData.conditions = conditions as unknown as Json;
      }
      if (actions) {
        updateData.actions = actions as unknown as Json;
      }

      const { data: rule, error } = await supabase
        .from('rules')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { ...rule, hub_id };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['rules', data.hub_id] });
      toast.success('Rule updated successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}

export function useDeleteRule() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, hub_id }: { id: string; hub_id: string }) => {
      const { error } = await supabase
        .from('rules')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { hub_id };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['rules', data.hub_id] });
      toast.success('Rule deleted successfully!');
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });
}
