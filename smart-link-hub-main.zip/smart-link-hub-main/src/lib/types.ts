export interface Profile {
  id: string;
  user_id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Hub {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  slug: string;
  theme: HubTheme;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface HubTheme {
  background: string;
  accent: string;
}

export interface Link {
  id: string;
  hub_id: string;
  title: string;
  url: string;
  description: string | null;
  icon: string | null;
  position: number;
  is_active: boolean;
  click_count: number;
  created_at: string;
  updated_at: string;
}

export type RuleType = 'time' | 'device' | 'location' | 'performance';

export interface Rule {
  id: string;
  hub_id: string;
  name: string;
  rule_type: RuleType;
  conditions: RuleConditions;
  actions: RuleActions;
  priority: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface RuleConditions {
  // Time-based
  start_time?: string;
  end_time?: string;
  days_of_week?: number[];
  start_date?: string;
  end_date?: string;
  
  // Device-based
  device_type?: 'mobile' | 'desktop' | 'tablet';
  
  // Location-based
  countries?: string[];
  regions?: string[];
  
  // Performance-based
  click_threshold?: number;
  comparison?: 'greater' | 'less';
}

export interface RuleActions {
  action: 'show' | 'hide' | 'promote' | 'demote';
  link_ids: string[];
  position?: number;
}

export interface HubVisit {
  id: string;
  hub_id: string;
  visitor_ip: string | null;
  user_agent: string | null;
  device_type: string | null;
  country: string | null;
  region: string | null;
  referrer: string | null;
  visited_at: string;
}

export interface LinkClick {
  id: string;
  link_id: string;
  hub_id: string;
  visitor_ip: string | null;
  user_agent: string | null;
  device_type: string | null;
  country: string | null;
  clicked_at: string;
}

export interface VisitorContext {
  deviceType: 'mobile' | 'desktop' | 'tablet';
  country?: string;
  region?: string;
  userAgent: string;
  currentTime: Date;
}
