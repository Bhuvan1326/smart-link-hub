import { Link, Rule, RuleConditions, VisitorContext } from './types';

export function evaluateRules(
  links: Link[],
  rules: Rule[],
  context: VisitorContext
): Link[] {
  // Sort rules by priority (higher priority first)
  const sortedRules = [...rules]
    .filter(r => r.is_active)
    .sort((a, b) => b.priority - a.priority);

  let processedLinks = [...links].filter(l => l.is_active);
  const hiddenLinkIds = new Set<string>();
  const promotedLinks: { linkId: string; position: number }[] = [];

  for (const rule of sortedRules) {
    if (!evaluateConditions(rule.conditions, rule.rule_type, context, processedLinks)) {
      continue;
    }

    // Apply actions
    const { action, link_ids, position } = rule.actions;

    switch (action) {
      case 'hide':
        link_ids.forEach(id => hiddenLinkIds.add(id));
        break;
      case 'show':
        link_ids.forEach(id => hiddenLinkIds.delete(id));
        break;
      case 'promote':
        link_ids.forEach(id => {
          promotedLinks.push({ linkId: id, position: position ?? 0 });
        });
        break;
      case 'demote':
        link_ids.forEach(id => {
          promotedLinks.push({ linkId: id, position: position ?? 999 });
        });
        break;
    }
  }

  // Filter out hidden links
  processedLinks = processedLinks.filter(l => !hiddenLinkIds.has(l.id));

  // Apply promotions/demotions
  const linkPositions = new Map<string, number>();
  processedLinks.forEach(link => {
    linkPositions.set(link.id, link.position);
  });

  promotedLinks.forEach(({ linkId, position }) => {
    if (linkPositions.has(linkId)) {
      linkPositions.set(linkId, position);
    }
  });

  // Sort by final positions
  processedLinks.sort((a, b) => {
    const posA = linkPositions.get(a.id) ?? a.position;
    const posB = linkPositions.get(b.id) ?? b.position;
    return posA - posB;
  });

  return processedLinks;
}

function evaluateConditions(
  conditions: RuleConditions,
  ruleType: string,
  context: VisitorContext,
  links: Link[]
): boolean {
  switch (ruleType) {
    case 'time':
      return evaluateTimeConditions(conditions, context);
    case 'device':
      return evaluateDeviceConditions(conditions, context);
    case 'location':
      return evaluateLocationConditions(conditions, context);
    case 'performance':
      return evaluatePerformanceConditions(conditions, links);
    default:
      return false;
  }
}

function evaluateTimeConditions(conditions: RuleConditions, context: VisitorContext): boolean {
  const now = context.currentTime;
  const currentHour = now.getHours();
  const currentMinutes = now.getMinutes();
  const currentTimeStr = `${currentHour.toString().padStart(2, '0')}:${currentMinutes.toString().padStart(2, '0')}`;
  const currentDay = now.getDay();

  // Check time range
  if (conditions.start_time && conditions.end_time) {
    if (currentTimeStr < conditions.start_time || currentTimeStr > conditions.end_time) {
      return false;
    }
  }

  // Check days of week
  if (conditions.days_of_week && conditions.days_of_week.length > 0) {
    if (!conditions.days_of_week.includes(currentDay)) {
      return false;
    }
  }

  // Check date range
  if (conditions.start_date) {
    const startDate = new Date(conditions.start_date);
    if (now < startDate) return false;
  }

  if (conditions.end_date) {
    const endDate = new Date(conditions.end_date);
    if (now > endDate) return false;
  }

  return true;
}

function evaluateDeviceConditions(conditions: RuleConditions, context: VisitorContext): boolean {
  if (conditions.device_type) {
    return context.deviceType === conditions.device_type;
  }
  return true;
}

function evaluateLocationConditions(conditions: RuleConditions, context: VisitorContext): boolean {
  if (conditions.countries && conditions.countries.length > 0) {
    if (!context.country || !conditions.countries.includes(context.country)) {
      return false;
    }
  }

  if (conditions.regions && conditions.regions.length > 0) {
    if (!context.region || !conditions.regions.includes(context.region)) {
      return false;
    }
  }

  return true;
}

function evaluatePerformanceConditions(conditions: RuleConditions, links: Link[]): boolean {
  if (conditions.click_threshold === undefined) return false;

  const threshold = conditions.click_threshold;
  const comparison = conditions.comparison ?? 'greater';

  // This evaluates for all links in the action - at least one must match
  return links.some(link => {
    if (comparison === 'greater') {
      return link.click_count > threshold;
    } else {
      return link.click_count < threshold;
    }
  });
}

export function detectDeviceType(userAgent: string): 'mobile' | 'desktop' | 'tablet' {
  const ua = userAgent.toLowerCase();
  
  if (/tablet|ipad|playbook|silk/i.test(ua)) {
    return 'tablet';
  }
  
  if (/mobile|iphone|ipod|android|blackberry|opera mini|iemobile/i.test(ua)) {
    return 'mobile';
  }
  
  return 'desktop';
}
