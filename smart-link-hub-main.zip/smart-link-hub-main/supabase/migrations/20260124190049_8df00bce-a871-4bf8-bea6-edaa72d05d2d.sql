-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create user_roles table
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Create profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    username TEXT UNIQUE,
    full_name TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create hubs table
CREATE TABLE public.hubs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    slug TEXT NOT NULL UNIQUE,
    theme JSONB DEFAULT '{"background": "#000000", "accent": "#39FF14"}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create links table
CREATE TABLE public.links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hub_id UUID REFERENCES public.hubs(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    position INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    click_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create rules table for the rule engine
CREATE TABLE public.rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hub_id UUID REFERENCES public.hubs(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    rule_type TEXT NOT NULL CHECK (rule_type IN ('time', 'device', 'location', 'performance')),
    conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
    actions JSONB NOT NULL DEFAULT '{}'::jsonb,
    priority INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create hub_visits table for analytics
CREATE TABLE public.hub_visits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hub_id UUID REFERENCES public.hubs(id) ON DELETE CASCADE NOT NULL,
    visitor_ip TEXT,
    user_agent TEXT,
    device_type TEXT,
    country TEXT,
    region TEXT,
    referrer TEXT,
    visited_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create link_clicks table for analytics
CREATE TABLE public.link_clicks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    link_id UUID REFERENCES public.links(id) ON DELETE CASCADE NOT NULL,
    hub_id UUID REFERENCES public.hubs(id) ON DELETE CASCADE NOT NULL,
    visitor_ip TEXT,
    user_agent TEXT,
    device_type TEXT,
    country TEXT,
    clicked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hubs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hub_visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.link_clicks ENABLE ROW LEVEL SECURITY;

-- Security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_roles
        WHERE user_id = _user_id
        AND role = _role
    )
$$;

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_hubs_updated_at BEFORE UPDATE ON public.hubs
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_links_updated_at BEFORE UPDATE ON public.links
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_rules_updated_at BEFORE UPDATE ON public.rules
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, username, full_name)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'full_name', '')
    );
    
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger for auto-creating profile
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles" ON public.user_roles
    FOR SELECT USING (auth.uid() = user_id);

-- RLS Policies for profiles
CREATE POLICY "Profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS Policies for hubs
CREATE POLICY "Users can view their own hubs" ON public.hubs
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view active hubs by slug" ON public.hubs
    FOR SELECT USING (is_active = true);

CREATE POLICY "Users can create their own hubs" ON public.hubs
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own hubs" ON public.hubs
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own hubs" ON public.hubs
    FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for links
CREATE POLICY "Users can view links of their hubs" ON public.links
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
        OR EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.is_active = true)
    );

CREATE POLICY "Users can create links for their hubs" ON public.links
    FOR INSERT WITH CHECK (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

CREATE POLICY "Users can update links of their hubs" ON public.links
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

CREATE POLICY "Users can delete links of their hubs" ON public.links
    FOR DELETE USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

-- RLS Policies for rules
CREATE POLICY "Users can view rules of their hubs" ON public.rules
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
        OR EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.is_active = true)
    );

CREATE POLICY "Users can create rules for their hubs" ON public.rules
    FOR INSERT WITH CHECK (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

CREATE POLICY "Users can update rules of their hubs" ON public.rules
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

CREATE POLICY "Users can delete rules of their hubs" ON public.rules
    FOR DELETE USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

-- RLS Policies for hub_visits (public insert, owner can view)
CREATE POLICY "Anyone can insert hub visits" ON public.hub_visits
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view visits for their hubs" ON public.hub_visits
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

-- RLS Policies for link_clicks (public insert, owner can view)
CREATE POLICY "Anyone can insert link clicks" ON public.link_clicks
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view clicks for their hubs" ON public.link_clicks
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.hubs WHERE hubs.id = hub_id AND hubs.user_id = auth.uid())
    );

-- Function to increment link click count
CREATE OR REPLACE FUNCTION public.increment_link_click(link_id_param UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE public.links
    SET click_count = click_count + 1
    WHERE id = link_id_param;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create indexes for performance
CREATE INDEX idx_hubs_user_id ON public.hubs(user_id);
CREATE INDEX idx_hubs_slug ON public.hubs(slug);
CREATE INDEX idx_links_hub_id ON public.links(hub_id);
CREATE INDEX idx_rules_hub_id ON public.rules(hub_id);
CREATE INDEX idx_hub_visits_hub_id ON public.hub_visits(hub_id);
CREATE INDEX idx_hub_visits_visited_at ON public.hub_visits(visited_at);
CREATE INDEX idx_link_clicks_link_id ON public.link_clicks(link_id);
CREATE INDEX idx_link_clicks_hub_id ON public.link_clicks(hub_id);
CREATE INDEX idx_link_clicks_clicked_at ON public.link_clicks(clicked_at);